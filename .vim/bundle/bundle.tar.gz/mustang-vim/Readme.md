Mustang Vim Colorscheme
=======================

This is a modified version of the awesome mustang colorscheme by hcalves,
published on [deviantART](http://hcalves.deviantart.com/art/Mustang-Vim-Colorscheme-98974484).

Modifications:

* Added coloring for NERDTree (best results with the classic NERDTree-layout)
